﻿namespace $safeprojectname$.Extension
{
    /// <summary>
    /// Содержит константы для системных наменований пользовательских контролов, свойств и событий
    /// </summary>
    internal static class Constants
    {

    }
}
