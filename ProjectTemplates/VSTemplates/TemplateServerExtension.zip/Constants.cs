﻿namespace $safeprojectname$
{
    /// <summary>
    /// Represents a static class for layout extension web constants
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Represents namespace
        /// </summary>
        public const string Namespace = "$safeprojectname$";
    }
}