﻿namespace $safeprojectname$
{
    /// <summary>
    /// Представляет собой статический класс для расширения разметки веб-констант
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Пространство имён
        /// </summary>
        public const string Namespace = "$safeprojectname$";
    }
}